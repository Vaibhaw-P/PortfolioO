## Packages
(none needed)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Syne'", "sans-serif"],
  body: ["'Space Grotesk'", "sans-serif"],
}
