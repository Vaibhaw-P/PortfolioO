import { Navigation } from "@/components/Navigation";
import { CursorLightImage } from "@/components/CursorLightImage";
import { motion } from "framer-motion";
import profilePic from "@assets/Profile_Pic1_1766817024951.JPG";

export default function About() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navigation />
      
      <main className="pt-32 px-6 lg:px-24 pb-24 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-32">
          
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="font-display font-bold text-5xl md:text-6xl leading-[0.9] mb-10">
              VAIBHAV<br />
              FULLSTACK <span className="text-stroke text-transparent hover:text-primary transition-colors duration-300">DEVELOPER</span>
            </h1>
            
            {/* Cursor light effect image */}
            <CursorLightImage
              src={profilePic}
              alt="Vaibhav profile"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex flex-col justify-center space-y-12"
          >
            <div className="space-y-6">
              <h3 className="font-body text-xs uppercase tracking-widest text-primary">My Approach</h3>
              <p className="font-body text-xl md:text-2xl leading-relaxed text-muted-foreground">
                I build web applications that are both beautiful and functional. I specialize in creating responsive interfaces with modern web technologies, focusing on user experience and clean code. I transform ideas into interactive digital experiences.
              </p>
            </div>

            <div className="space-y-6">
              <h3 className="font-body text-xs uppercase tracking-widest text-primary">The Stack</h3>
              <div className="grid grid-cols-2 gap-4 font-display text-2xl font-bold">
                <div className="border-b border-border py-2">React</div>
                <div className="border-b border-border py-2">TypeScript</div>
                <div className="border-b border-border py-2">WebGL</div>
                <div className="border-b border-border py-2">Node.js</div>
                <div className="border-b border-border py-2">Design Systems</div>
                <div className="border-b border-border py-2">Motion</div>
              </div>
            </div>

            <div className="pt-12 space-y-8">
              <a href="/contact" className="inline-block px-12 py-6 border border-foreground font-display font-bold text-xl hover:bg-primary hover:text-background hover:border-primary transition-all duration-300">
                LET'S WORK TOGETHER
              </a>
              
              <div className="flex gap-8 pt-8">
                <a 
                  href="https://github.com/Vaibhaw-P" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="font-display font-bold text-lg text-foreground hover:text-primary transition-colors duration-300 underline underline-offset-4"
                  data-testid="link-github"
                >
                  GITHUB
                </a>
                <a 
                  href="https://www.linkedin.com/in/vaibhavpandeydev/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="font-display font-bold text-lg text-foreground hover:text-primary transition-colors duration-300 underline underline-offset-4"
                  data-testid="link-linkedin"
                >
                  LINKEDIN
                </a>
              </div>
            </div>
          </motion.div>

        </div>
      </main>
    </div>
  );
}
