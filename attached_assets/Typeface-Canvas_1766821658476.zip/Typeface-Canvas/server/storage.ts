import { db } from "./db";
import { projects, messages, type InsertProject, type InsertMessage } from "@shared/schema";

export interface IStorage {
  getProjects(): Promise<typeof projects.$inferSelect[]>;
  createProject(project: InsertProject): Promise<typeof projects.$inferSelect>;
  createMessage(message: InsertMessage): Promise<typeof messages.$inferSelect>;
}

export class DatabaseStorage implements IStorage {
  async getProjects() {
    return await db.select().from(projects);
  }

  async createProject(project: InsertProject) {
    const [newProject] = await db.insert(projects).values(project).returning();
    return newProject;
  }

  async createMessage(message: InsertMessage) {
    const [newMessage] = await db.insert(messages).values(message).returning();
    return newMessage;
  }
}

export const storage = new DatabaseStorage();
